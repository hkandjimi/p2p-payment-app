import * as i0 from '@angular/core';
import { OnInit, OnDestroy, EventEmitter, ElementRef, ChangeDetectorRef } from '@angular/core';
import * as i4 from '@angular/cdk/overlay';
import { Overlay, OverlayPositionBuilder } from '@angular/cdk/overlay';
import { Subject } from 'rxjs';
import { AnimationEvent } from '@angular/animations';
import * as i3 from '@angular/common';

type MdbTooltipPosition = 'top' | 'right' | 'bottom' | 'left';

declare class MdbTooltipDirective implements OnInit, OnDestroy {
    private _overlay;
    private _overlayPositionBuilder;
    private _elementRef;
    mdbTooltip: string;
    tooltipDisabled: boolean;
    placement: MdbTooltipPosition;
    html: boolean;
    animation: boolean;
    trigger: string;
    delayShow: number;
    delayHide: number;
    offset: number;
    tooltipShow: EventEmitter<MdbTooltipDirective>;
    tooltipShown: EventEmitter<MdbTooltipDirective>;
    tooltipHide: EventEmitter<MdbTooltipDirective>;
    tooltipHidden: EventEmitter<MdbTooltipDirective>;
    private _overlayRef;
    private _tooltipRef;
    private _open;
    private _showTimeout;
    private _hideTimeout;
    private _cdRef;
    readonly _destroy$: Subject<void>;
    constructor(_overlay: Overlay, _overlayPositionBuilder: OverlayPositionBuilder, _elementRef: ElementRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private _bindTriggerEvents;
    private _createOverlayConfig;
    private _createOverlay;
    private _getPosition;
    show(): void;
    hide(): void;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbTooltipDirective, "[mdbTooltip]", ["mdbTooltip"], { "mdbTooltip": { "alias": "mdbTooltip"; "required": false; }; "tooltipDisabled": { "alias": "tooltipDisabled"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "html": { "alias": "html"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "trigger": { "alias": "trigger"; "required": false; }; "delayShow": { "alias": "delayShow"; "required": false; }; "delayHide": { "alias": "delayHide"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, { "tooltipShow": "tooltipShow"; "tooltipShown": "tooltipShown"; "tooltipHide": "tooltipHide"; "tooltipHidden": "tooltipHidden"; }, never, never, false, never>;
}

declare class MdbTooltipComponent {
    private _cdRef;
    title: string;
    html: boolean;
    animation: boolean;
    tooltip: boolean;
    readonly _hidden: Subject<void>;
    animationState: string;
    constructor(_cdRef: ChangeDetectorRef);
    markForCheck(): void;
    detectChanges(): void;
    onAnimationEnd(event: AnimationEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbTooltipComponent, "mdb-tooltip", never, { "title": { "alias": "title"; "required": false; }; "html": { "alias": "html"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MdbTooltipModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTooltipModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbTooltipModule, [typeof MdbTooltipDirective, typeof MdbTooltipComponent], [typeof i3.CommonModule, typeof i4.OverlayModule], [typeof MdbTooltipDirective, typeof MdbTooltipComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbTooltipModule>;
}

export { MdbTooltipComponent, MdbTooltipDirective, MdbTooltipModule };
export type { MdbTooltipPosition };
