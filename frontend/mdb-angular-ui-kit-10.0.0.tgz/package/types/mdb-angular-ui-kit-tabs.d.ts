import { BooleanInput } from '@angular/cdk/coercion';
import * as i7 from '@angular/cdk/portal';
import { TemplatePortal, CdkPortalOutlet } from '@angular/cdk/portal';
import * as i0 from '@angular/core';
import { OnInit, TemplateRef, ViewContainerRef, ChangeDetectorRef, AfterContentInit, OnDestroy, QueryList, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';
import * as i6 from '@angular/common';

declare class MdbTabComponent implements OnInit {
    private _vcr;
    private _cdRef;
    _lazyContent: TemplateRef<any>;
    _titleContent: TemplateRef<any>;
    _content: TemplateRef<any>;
    readonly activeStateChange$: Subject<boolean>;
    get disabled(): boolean;
    set disabled(value: boolean);
    private _disabled;
    get fade(): boolean;
    set fade(value: boolean);
    private _fade;
    title: string;
    get content(): TemplatePortal | null;
    get titleContent(): TemplatePortal | null;
    get shouldAttach(): boolean;
    private _contentPortal;
    private _titlePortal;
    get active(): boolean;
    set active(value: boolean);
    private _active;
    get show(): boolean;
    set show(value: boolean);
    private _show;
    constructor(_vcr: ViewContainerRef, _cdRef: ChangeDetectorRef);
    ngOnInit(): void;
    private _createContentPortal;
    private _createTitlePortal;
    static ngAcceptInputType_disabled: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbTabComponent, "mdb-tab", never, { "disabled": { "alias": "disabled"; "required": false; }; "fade": { "alias": "fade"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, ["_lazyContent", "_titleContent"], ["*"], false, never>;
}

declare class MdbTabContentDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTabContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbTabContentDirective, "[mdbTabContent]", never, {}, {}, never, never, false, never>;
}

declare class MdbTabTitleDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTabTitleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbTabTitleDirective, "[mdbTabTitle]", never, {}, {}, never, never, false, never>;
}

declare class MdbTabChange {
    index: number;
    tab: MdbTabComponent;
}
declare class MdbTabsComponent implements AfterContentInit, OnDestroy {
    tabs: QueryList<MdbTabComponent>;
    readonly _destroy$: Subject<void>;
    get fill(): boolean;
    set fill(value: boolean);
    private _fill;
    get justified(): boolean;
    set justified(value: boolean);
    private _justified;
    get pills(): boolean;
    set pills(value: boolean);
    private _pills;
    get vertical(): boolean;
    set vertical(value: boolean);
    private _vertical;
    navColumnClass: string;
    contentColumnClass: string;
    private _cdRef;
    get navColClass(): string;
    get contentColClass(): string;
    private _selectedIndex;
    activeTabChange: EventEmitter<MdbTabChange>;
    ngAfterContentInit(): void;
    setActiveTab(index: number): void;
    private _getTabChangeEvent;
    private _getClosestTabIndex;
    ngOnDestroy(): void;
    static ngAcceptInputType_fill: BooleanInput;
    static ngAcceptInputType_justified: BooleanInput;
    static ngAcceptInputType_pills: BooleanInput;
    static ngAcceptInputType_vertical: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbTabsComponent, "mdb-tabs", never, { "fill": { "alias": "fill"; "required": false; }; "justified": { "alias": "justified"; "required": false; }; "pills": { "alias": "pills"; "required": false; }; "vertical": { "alias": "vertical"; "required": false; }; "navColumnClass": { "alias": "navColumnClass"; "required": false; }; "contentColumnClass": { "alias": "contentColumnClass"; "required": false; }; }, { "activeTabChange": "activeTabChange"; }, ["tabs"], never, false, never>;
}

declare class MdbTabPortalOutlet extends CdkPortalOutlet implements OnInit, OnDestroy {
    readonly _destroy$: Subject<void>;
    tab: MdbTabComponent;
    constructor(_vcr: ViewContainerRef, _document: any);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTabPortalOutlet, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbTabPortalOutlet, "[mdbTabPortalOutlet]", never, { "tab": { "alias": "tab"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MdbTabsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTabsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbTabsModule, [typeof MdbTabComponent, typeof MdbTabContentDirective, typeof MdbTabTitleDirective, typeof MdbTabPortalOutlet, typeof MdbTabsComponent], [typeof i6.CommonModule, typeof i7.PortalModule], [typeof MdbTabComponent, typeof MdbTabContentDirective, typeof MdbTabTitleDirective, typeof MdbTabPortalOutlet, typeof MdbTabsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbTabsModule>;
}

export { MdbTabChange, MdbTabComponent, MdbTabContentDirective, MdbTabPortalOutlet, MdbTabTitleDirective, MdbTabsComponent, MdbTabsModule };
