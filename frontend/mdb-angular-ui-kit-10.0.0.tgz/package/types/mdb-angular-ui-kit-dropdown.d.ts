import * as i0 from '@angular/core';
import { ElementRef, Renderer2, EventEmitter, OnDestroy, AfterContentInit, TemplateRef, ViewContainerRef, ChangeDetectorRef } from '@angular/core';
import * as i5 from '@angular/cdk/overlay';
import { Overlay, OverlayPositionBuilder } from '@angular/cdk/overlay';
import { Subject } from 'rxjs';
import { AnimationEvent } from '@angular/animations';
import { BreakpointObserver } from '@angular/cdk/layout';
import * as i4 from '@angular/common';

declare class MdbDropdownMenuDirective {
    elementRef: ElementRef;
    private _renderer;
    constructor(elementRef: ElementRef, _renderer: Renderer2);
    menuPositionClassChanged: EventEmitter<string>;
    get menuPositionClass(): string;
    set menuPositionClass(newClass: string);
    private _menuPositionClass;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDropdownMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbDropdownMenuDirective, "[mdbDropdownMenu]", ["mdbDropdownMenu"], { "menuPositionClass": { "alias": "menuPositionClass"; "required": false; }; }, { "menuPositionClassChanged": "menuPositionClassChanged"; }, never, never, false, never>;
}

type MdbDropdownPositionClass = 'dropdown' | 'dropup' | 'dropstart' | 'dropend';
declare class MdbDropdownDirective implements OnDestroy, AfterContentInit {
    private _overlay;
    private _overlayPositionBuilder;
    private _elementRef;
    private _vcr;
    private _breakpointObserver;
    private _cdRef;
    private _renderer;
    _template: TemplateRef<any>;
    _dropdownToggle: ElementRef;
    _dropdownMenu: MdbDropdownMenuDirective;
    animation: boolean;
    closeOnEsc: boolean;
    closeOnItemClick: boolean;
    closeOnOutsideClick: boolean;
    offset: number;
    get positionClass(): MdbDropdownPositionClass;
    set positionClass(newClass: MdbDropdownPositionClass);
    private _positionClass;
    withPush: boolean;
    dropdownShow: EventEmitter<MdbDropdownDirective>;
    dropdownShown: EventEmitter<MdbDropdownDirective>;
    dropdownHide: EventEmitter<MdbDropdownDirective>;
    dropdownHidden: EventEmitter<MdbDropdownDirective>;
    private _overlayRef;
    private _portal;
    private _open;
    private _isDropUp;
    private _isDropStart;
    private _isDropEnd;
    private _isDropdownMenuEnd;
    private _xPosition;
    private _breakpoints;
    private _mousedownTarget;
    readonly _destroy$: Subject<void>;
    get host(): HTMLElement;
    _breakpointSubscription: any;
    _animationState: string;
    constructor(_overlay: Overlay, _overlayPositionBuilder: OverlayPositionBuilder, _elementRef: ElementRef, _vcr: ViewContainerRef, _breakpointObserver: BreakpointObserver, _cdRef: ChangeDetectorRef, _renderer: Renderer2);
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private _bindDropdownToggleClick;
    private _listenToMenuPositionClassChange;
    private _updateOverlay;
    private _createOverlayConfig;
    private _createOverlay;
    private _createPositionStrategy;
    private _getPosition;
    private _listenToEscKeyup;
    private _listenToMousedown;
    private _listenToClick;
    onAnimationEnd(event: AnimationEvent): void;
    private _subscribeBrakpoints;
    show(): void;
    private _handleKeyboardNavigation;
    hide(): void;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDropdownDirective, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbDropdownDirective, "[mdbDropdown]", never, { "animation": { "alias": "animation"; "required": false; }; "closeOnEsc": { "alias": "closeOnEsc"; "required": false; }; "closeOnItemClick": { "alias": "closeOnItemClick"; "required": false; }; "closeOnOutsideClick": { "alias": "closeOnOutsideClick"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "positionClass": { "alias": "positionClass"; "required": false; }; "withPush": { "alias": "withPush"; "required": false; }; }, { "dropdownShow": "dropdownShow"; "dropdownShown": "dropdownShown"; "dropdownHide": "dropdownHide"; "dropdownHidden": "dropdownHidden"; }, ["_dropdownToggle", "_dropdownMenu"], ["*", ".dropdown-toggle", ".dropdown-menu"], false, never>;
    static ngAcceptInputType_animation: unknown;
    static ngAcceptInputType_closeOnEsc: unknown;
    static ngAcceptInputType_closeOnItemClick: unknown;
    static ngAcceptInputType_closeOnOutsideClick: unknown;
    static ngAcceptInputType_offset: unknown;
    static ngAcceptInputType_withPush: unknown;
}

declare class MdbDropdownToggleDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDropdownToggleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbDropdownToggleDirective, "[mdbDropdownToggle]", ["mdbDropdownToggle"], {}, {}, never, never, false, never>;
}

declare class MdbDropdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDropdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbDropdownModule, [typeof MdbDropdownDirective, typeof MdbDropdownToggleDirective, typeof MdbDropdownMenuDirective], [typeof i4.CommonModule, typeof i5.OverlayModule], [typeof MdbDropdownDirective, typeof MdbDropdownToggleDirective, typeof MdbDropdownMenuDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbDropdownModule>;
}

export { MdbDropdownDirective, MdbDropdownMenuDirective, MdbDropdownModule, MdbDropdownToggleDirective };
export type { MdbDropdownPositionClass };
