import { BooleanInput } from '@angular/cdk/coercion';
import * as i0 from '@angular/core';
import { AfterContentInit, OnDestroy, QueryList } from '@angular/core';
import * as i4 from '@angular/forms';
import { ControlValueAccessor } from '@angular/forms';
import * as i3 from '@angular/common';

declare class MdbRadioDirective {
    get name(): string;
    set name(value: string);
    private _name;
    get checked(): boolean;
    set checked(value: boolean);
    private _checked;
    get value(): any;
    set value(value: any);
    private _value;
    get disabled(): boolean;
    set disabled(value: boolean);
    private _disabled;
    get isDisabled(): boolean;
    get isChecked(): boolean;
    get nameAttr(): string;
    constructor();
    _updateName(value: string): void;
    _updateChecked(value: boolean): void;
    _updateDisabledState(value: boolean): void;
    static ngAcceptInputType_checked: BooleanInput;
    static ngAcceptInputType_disabled: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbRadioDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbRadioDirective, "[mdbRadio]", never, { "name": { "alias": "name"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "value": { "alias": "value"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, never, false, never>;
}

declare const MDB_RADIO_GROUP_VALUE_ACCESSOR: any;
declare class MdbRadioGroupDirective implements ControlValueAccessor, AfterContentInit, OnDestroy {
    radios: QueryList<MdbRadioDirective>;
    get value(): any;
    set value(value: any);
    private _value;
    get name(): string;
    set name(name: string);
    private _name;
    get disabled(): boolean;
    set disabled(disabled: boolean);
    private _disabled;
    private _destroy$;
    onChange: (_: any) => void;
    onTouched: () => void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private _updateRadiosState;
    private _updateNames;
    private _updateChecked;
    private _updateDisabled;
    registerOnChange(fn: (value: any) => any): void;
    registerOnTouched(fn: () => any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbRadioGroupDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbRadioGroupDirective, "[mdbRadioGroup]", never, { "value": { "alias": "value"; "required": false; }; "name": { "alias": "name"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, ["radios"], never, false, never>;
}

declare class MdbRadioModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbRadioModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbRadioModule, [typeof MdbRadioDirective, typeof MdbRadioGroupDirective], [typeof i3.CommonModule, typeof i4.FormsModule], [typeof MdbRadioDirective, typeof MdbRadioGroupDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbRadioModule>;
}

export { MDB_RADIO_GROUP_VALUE_ACCESSOR, MdbRadioDirective, MdbRadioGroupDirective, MdbRadioModule };
