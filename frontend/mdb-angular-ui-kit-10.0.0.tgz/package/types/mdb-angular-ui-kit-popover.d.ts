import * as i0 from '@angular/core';
import { OnInit, OnDestroy, TemplateRef, EventEmitter, ElementRef, ChangeDetectorRef } from '@angular/core';
import * as i4 from '@angular/cdk/overlay';
import { Overlay, OverlayPositionBuilder } from '@angular/cdk/overlay';
import { Subject } from 'rxjs';
import { AnimationEvent } from '@angular/animations';
import * as i3 from '@angular/common';

type MdbPopoverPosition = 'top' | 'right' | 'bottom' | 'left';

declare class MdbPopoverDirective implements OnInit, OnDestroy {
    private _overlay;
    private _overlayPositionBuilder;
    private _elementRef;
    animation: boolean;
    delayHide: number;
    delayShow: number;
    mdbPopover: TemplateRef<any> | string;
    mdbPopoverData: any;
    mdbPopoverTitle: string;
    offset: number;
    placement: MdbPopoverPosition;
    popoverDisabled: boolean;
    trigger: string;
    popoverShow: EventEmitter<MdbPopoverDirective>;
    popoverShown: EventEmitter<MdbPopoverDirective>;
    popoverHide: EventEmitter<MdbPopoverDirective>;
    popoverHidden: EventEmitter<MdbPopoverDirective>;
    private _overlayRef;
    private _tooltipRef;
    private _open;
    private _showTimeout;
    private _hideTimeout;
    readonly _destroy$: Subject<void>;
    constructor(_overlay: Overlay, _overlayPositionBuilder: OverlayPositionBuilder, _elementRef: ElementRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    private _bindTriggerEvents;
    private _createOverlayConfig;
    private _createOverlay;
    private _getPosition;
    show(): void;
    hide(): void;
    toggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbPopoverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbPopoverDirective, "[mdbPopover]", ["mdbPopover"], { "animation": { "alias": "animation"; "required": false; }; "delayHide": { "alias": "delayHide"; "required": false; }; "delayShow": { "alias": "delayShow"; "required": false; }; "mdbPopover": { "alias": "mdbPopover"; "required": false; }; "mdbPopoverData": { "alias": "mdbPopoverData"; "required": false; }; "mdbPopoverTitle": { "alias": "mdbPopoverTitle"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; "placement": { "alias": "placement"; "required": false; }; "popoverDisabled": { "alias": "popoverDisabled"; "required": false; }; "trigger": { "alias": "trigger"; "required": false; }; }, { "popoverShow": "popoverShow"; "popoverShown": "popoverShown"; "popoverHide": "popoverHide"; "popoverHidden": "popoverHidden"; }, never, never, false, never>;
    static ngAcceptInputType_animation: unknown;
    static ngAcceptInputType_delayHide: unknown;
    static ngAcceptInputType_delayShow: unknown;
    static ngAcceptInputType_offset: unknown;
    static ngAcceptInputType_popoverDisabled: unknown;
}

declare class MdbPopoverComponent {
    private _cdRef;
    animation: boolean;
    content: string | TemplateRef<any>;
    context: any;
    title: string;
    get isContentTemplate(): boolean;
    readonly _hidden: Subject<void>;
    animationState: string;
    constructor(_cdRef: ChangeDetectorRef);
    markForCheck(): void;
    onAnimationEnd(event: AnimationEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbPopoverComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbPopoverComponent, "mdb-popover", never, { "animation": { "alias": "animation"; "required": false; }; "content": { "alias": "content"; "required": false; }; "context": { "alias": "context"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, never, false, never>;
    static ngAcceptInputType_animation: unknown;
}

declare class MdbPopoverModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbPopoverModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbPopoverModule, [typeof MdbPopoverDirective, typeof MdbPopoverComponent], [typeof i3.CommonModule, typeof i4.OverlayModule], [typeof MdbPopoverDirective, typeof MdbPopoverComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbPopoverModule>;
}

export { MdbPopoverComponent, MdbPopoverDirective, MdbPopoverModule };
export type { MdbPopoverPosition };
