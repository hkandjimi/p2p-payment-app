import { BooleanInput } from '@angular/cdk/coercion';
import * as i0 from '@angular/core';
import { OnInit, Renderer2, ElementRef, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';
import * as i4 from '@angular/common';

declare class MdbValidateDirective implements OnInit {
    private renderer;
    private _elementRef;
    private _validate;
    private _validateSuccess;
    private _validateError;
    get mdbValidate(): boolean;
    set mdbValidate(value: boolean);
    private _mdbValidate;
    get validate(): boolean;
    set validate(value: boolean);
    get validateSuccess(): boolean;
    set validateSuccess(value: boolean);
    get validateError(): boolean;
    set validateError(value: boolean);
    constructor(renderer: Renderer2, _elementRef: ElementRef);
    updateSuccessClass(): void;
    updateErrorClass(): void;
    ngOnInit(): void;
    static ngAcceptInputType_mdbValidate: BooleanInput;
    static ngAcceptInputType_validate: BooleanInput;
    static ngAcceptInputType_validateSuccess: BooleanInput;
    static ngAcceptInputType_validateError: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbValidateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbValidateDirective, "[mdbValidate]", never, { "mdbValidate": { "alias": "mdbValidate"; "required": false; }; "validate": { "alias": "validate"; "required": false; }; "validateSuccess": { "alias": "validateSuccess"; "required": false; }; "validateError": { "alias": "validateError"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MdbErrorDirective implements OnInit, OnDestroy {
    private _elementRef;
    private renderer;
    id: string;
    errorMsg: boolean;
    messageId: string;
    readonly _destroy$: Subject<void>;
    constructor(_elementRef: ElementRef, renderer: Renderer2);
    private _getClosestEl;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbErrorDirective, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbErrorDirective, "mdb-error", never, { "id": { "alias": "id"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class MdbSuccessDirective implements OnInit, OnDestroy {
    private _elementRef;
    private renderer;
    id: string;
    successMsg: boolean;
    messageId: string;
    readonly _destroy$: Subject<void>;
    constructor(_elementRef: ElementRef, renderer: Renderer2);
    private _getClosestEl;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbSuccessDirective, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbSuccessDirective, "mdb-success", never, { "id": { "alias": "id"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class MdbValidationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbValidationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbValidationModule, [typeof MdbErrorDirective, typeof MdbSuccessDirective, typeof MdbValidateDirective], [typeof i4.CommonModule], [typeof MdbErrorDirective, typeof MdbSuccessDirective, typeof MdbValidateDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbValidationModule>;
}

export { MdbErrorDirective, MdbSuccessDirective, MdbValidateDirective, MdbValidationModule };
