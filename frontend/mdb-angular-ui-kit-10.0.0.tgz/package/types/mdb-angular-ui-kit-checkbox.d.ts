import { BooleanInput } from '@angular/cdk/coercion';
import * as i0 from '@angular/core';
import { EventEmitter } from '@angular/core';
import * as i2 from '@angular/common';
import * as i3 from '@angular/forms';

declare const MDB_CHECKBOX_VALUE_ACCESSOR: any;
declare class MdbCheckboxChange {
    element: MdbCheckboxDirective;
    checked: boolean;
}
declare class MdbCheckboxDirective {
    get checked(): boolean;
    set checked(value: boolean);
    private _checked;
    get value(): any;
    set value(value: any);
    private _value;
    get disabled(): boolean;
    set disabled(value: boolean);
    private _disabled;
    checkboxChange: EventEmitter<MdbCheckboxChange>;
    get isDisabled(): boolean;
    get isChecked(): boolean;
    onCheckboxClick(): void;
    onBlur(): void;
    private _cdRef;
    get changeEvent(): MdbCheckboxChange;
    toggle(): void;
    onCheckboxChange(): void;
    onChange: (_: any) => void;
    onTouched: () => void;
    writeValue(value: any): void;
    registerOnChange(fn: (_: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ngAcceptInputType_checked: BooleanInput;
    static ngAcceptInputType_disabled: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbCheckboxDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbCheckboxDirective, "[mdbCheckbox]", never, { "checked": { "alias": "checked"; "required": false; }; "value": { "alias": "value"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "checkboxChange": "checkboxChange"; }, never, never, false, never>;
}

declare class MdbCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbCheckboxModule, [typeof MdbCheckboxDirective], [typeof i2.CommonModule, typeof i3.FormsModule], [typeof MdbCheckboxDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbCheckboxModule>;
}

export { MDB_CHECKBOX_VALUE_ACCESSOR, MdbCheckboxChange, MdbCheckboxDirective, MdbCheckboxModule };
