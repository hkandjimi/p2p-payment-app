import * as i0 from '@angular/core';
import { AfterContentInit, AfterContentChecked, OnDestroy, ElementRef, Renderer2, Injector, DoCheck, AfterViewInit, OnInit, DestroyRef } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { ContentObserver } from '@angular/cdk/observers';
import { BooleanInput } from '@angular/cdk/coercion';
import * as i5 from '@angular/forms';
import { NgControl } from '@angular/forms';
import { AutofillMonitor } from '@angular/cdk/text-field';
import * as i4 from '@angular/common';

declare abstract class MdbAbstractFormControl<T> {
    readonly stateChanges: Observable<void>;
    readonly input: HTMLInputElement;
    readonly labelActive: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbAbstractFormControl<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbAbstractFormControl<any>, never, never, {}, {}, never, never, true, never>;
}

declare class MdbFormControlComponent implements AfterContentInit, AfterContentChecked, OnDestroy {
    private _renderer;
    private _contentObserver;
    private _elementRef;
    private _injector;
    _notchLeading: ElementRef;
    _notchMiddle: ElementRef;
    _formControl: MdbAbstractFormControl<any>;
    _label: ElementRef;
    outline: boolean;
    display: boolean;
    private _cdRef;
    get input(): HTMLInputElement;
    constructor(_renderer: Renderer2, _contentObserver: ContentObserver, _elementRef: ElementRef, _injector: Injector);
    readonly _destroy$: Subject<void>;
    private _notchLeadingLength;
    private _labelMarginLeft;
    private _labelGapPadding;
    private _labelScale;
    private _recalculateGapWhenVisible;
    private _previousLabel;
    ngAfterContentInit(): void;
    ngAfterContentChecked(): void;
    ngOnDestroy(): void;
    get hasLabel(): boolean;
    private _getLabelWidth;
    private _updateBorderGap;
    private _updateLabelActiveState;
    private _isLabelActive;
    private _isHidden;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbFormControlComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbFormControlComponent, "mdb-form-control", never, {}, {}, ["_formControl", "_label"], ["*"], false, never>;
}

declare class MdbInputDirective implements MdbAbstractFormControl<any>, DoCheck, AfterViewInit, OnInit, OnDestroy {
    private _elementRef;
    private _renderer;
    private _ngControl;
    private _autofill;
    private _destroyRef;
    private _cdRef;
    constructor(_elementRef: ElementRef, _renderer: Renderer2, _ngControl: NgControl, _autofill: AutofillMonitor, _destroyRef: DestroyRef);
    readonly stateChanges: Subject<void>;
    private _focused;
    private _autofilled;
    private _color;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private _currentNativeValue;
    get disabled(): boolean;
    set disabled(value: boolean);
    private _disabled;
    get readonly(): boolean;
    set readonly(value: boolean);
    private _readonly;
    get value(): string;
    set value(value: string);
    private _value;
    private _updateTextColorForDateType;
    _onFocus(): void;
    _onBlur(): void;
    ngDoCheck(): void;
    get hasValue(): boolean;
    get focused(): boolean;
    get autofilled(): boolean;
    get input(): HTMLInputElement;
    get labelActive(): boolean;
    private _hasTypeInterferingPlaceholder;
    static ngAcceptInputType_disabled: BooleanInput;
    static ngAcceptInputType_readonly: BooleanInput;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbInputDirective, [null, null, { optional: true; self: true; }, null, null]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbInputDirective, "[mdbInput]", ["mdbInput"], { "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MdbLabelDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbLabelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbLabelDirective, "[mdbLabel]", ["mdbLabel"], {}, {}, never, never, false, never>;
}

declare class MdbFormsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbFormsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbFormsModule, [typeof MdbFormControlComponent, typeof MdbInputDirective, typeof MdbLabelDirective], [typeof i4.CommonModule, typeof i5.FormsModule], [typeof MdbFormControlComponent, typeof MdbInputDirective, typeof MdbLabelDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbFormsModule>;
}

export { MdbAbstractFormControl, MdbFormControlComponent, MdbFormsModule, MdbInputDirective, MdbLabelDirective };
