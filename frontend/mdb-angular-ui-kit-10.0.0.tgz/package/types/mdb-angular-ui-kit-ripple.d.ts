import { BooleanInput } from '@angular/cdk/coercion';
import * as i0 from '@angular/core';
import { ElementRef, Renderer2 } from '@angular/core';

declare class MdbRippleDirective {
    private _elementRef;
    private _renderer;
    get rippleCentered(): boolean;
    set rippleCentered(value: boolean);
    private _rippleCentered;
    rippleColor: string;
    rippleDuration: string;
    rippleRadius: number;
    get rippleUnbound(): boolean;
    set rippleUnbound(value: boolean);
    private _rippleUnbound;
    private _rippleInSpan;
    private _rippleTimer;
    constructor(_elementRef: ElementRef, _renderer: Renderer2);
    get host(): HTMLElement;
    ripple: boolean;
    _createRipple(event: any): void;
    private _createWrapperSpan;
    _removeWrapperSpan(): void;
    private _createHTMLRipple;
    private _removeHTMLRipple;
    _appendRipple(target: HTMLElement, parent: HTMLElement): void;
    _toggleUnbound(target: HTMLElement): void;
    _addColor(target: HTMLElement, parent: HTMLElement): void;
    _removeOldColorClasses(target: HTMLElement): void;
    static ngAcceptInputType_rippleCentered: BooleanInput;
    static ngAcceptInputType_rippleUnbound: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbRippleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbRippleDirective, "[mdbRipple]", ["mdbRipple"], { "rippleCentered": { "alias": "rippleCentered"; "required": false; }; "rippleColor": { "alias": "rippleColor"; "required": false; }; "rippleDuration": { "alias": "rippleDuration"; "required": false; }; "rippleRadius": { "alias": "rippleRadius"; "required": false; }; "rippleUnbound": { "alias": "rippleUnbound"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MdbRippleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbRippleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbRippleModule, [typeof MdbRippleDirective], never, [typeof MdbRippleDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbRippleModule>;
}

export { MdbRippleDirective, MdbRippleModule };
