import * as i0 from '@angular/core';
import { OnInit, TemplateRef, EventEmitter, ChangeDetectorRef, AfterContentInit, QueryList } from '@angular/core';
import * as i6 from 'mdb-angular-ui-kit/collapse';
import { MdbCollapseDirective } from 'mdb-angular-ui-kit/collapse';
import { Subject } from 'rxjs';
import { BooleanInput } from '@angular/cdk/coercion';
import * as i5 from '@angular/common';

declare class MdbAccordionItemComponent implements OnInit {
    private _cdRef;
    _headerTemplate: TemplateRef<any>;
    _bodyTemplate: TemplateRef<any>;
    collapse: MdbCollapseDirective;
    get disabled(): boolean;
    set disabled(value: boolean);
    private _disabled;
    header: string;
    set collapsed(value: boolean);
    id: string;
    _headerId: string;
    private _isInitialized;
    private _shouldOpenOnInit;
    itemShow: EventEmitter<MdbAccordionItemComponent>;
    itemShown: EventEmitter<MdbAccordionItemComponent>;
    itemHide: EventEmitter<MdbAccordionItemComponent>;
    itemHidden: EventEmitter<MdbAccordionItemComponent>;
    accordionItem: boolean;
    accordionItemDisplayBlock: boolean;
    ngOnInit(): void;
    show$: Subject<MdbAccordionItemComponent>;
    _collapsed: boolean;
    _addCollapsedClass: boolean;
    constructor(_cdRef: ChangeDetectorRef);
    toggle(): void;
    show(): void;
    hide(): void;
    onShow(): void;
    onHide(): void;
    onShown(): void;
    onHidden(): void;
    static ngAcceptInputType_disabled: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbAccordionItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbAccordionItemComponent, "mdb-accordion-item", never, { "disabled": { "alias": "disabled"; "required": false; }; "header": { "alias": "header"; "required": false; }; "collapsed": { "alias": "collapsed"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, { "itemShow": "itemShow"; "itemShown": "itemShown"; "itemHide": "itemHide"; "itemHidden": "itemHidden"; }, ["_headerTemplate", "_bodyTemplate"], never, false, never>;
}

declare class MdbAccordionComponent implements AfterContentInit {
    items: QueryList<MdbAccordionItemComponent>;
    get borderless(): boolean;
    set borderless(value: boolean);
    private _borderless;
    get flush(): boolean;
    set flush(value: boolean);
    private _flush;
    get multiple(): boolean;
    set multiple(value: boolean);
    private _multiple;
    accordion: boolean;
    get addBorderlessClass(): boolean;
    get addFlushClass(): boolean;
    constructor();
    ngAfterContentInit(): void;
    private _handleMultipleItems;
    static ngAcceptInputType_borderless: BooleanInput;
    static ngAcceptInputType_flush: BooleanInput;
    static ngAcceptInputType_multiple: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbAccordionComponent, "mdb-accordion", never, { "borderless": { "alias": "borderless"; "required": false; }; "flush": { "alias": "flush"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; }, {}, ["items"], ["*"], false, never>;
}

declare class MdbAccordionItemHeaderDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbAccordionItemHeaderDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbAccordionItemHeaderDirective, "[mdbAccordionItemHeader]", never, {}, {}, never, never, false, never>;
}

declare class MdbAccordionItemBodyDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbAccordionItemBodyDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbAccordionItemBodyDirective, "[mdbAccordionItemBody]", never, {}, {}, never, never, false, never>;
}

declare class MdbAccordionModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbAccordionModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbAccordionModule, [typeof MdbAccordionComponent, typeof MdbAccordionItemComponent, typeof MdbAccordionItemHeaderDirective, typeof MdbAccordionItemBodyDirective], [typeof i5.CommonModule, typeof i6.MdbCollapseModule], [typeof MdbAccordionComponent, typeof MdbAccordionItemComponent, typeof MdbAccordionItemHeaderDirective, typeof MdbAccordionItemBodyDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbAccordionModule>;
}

export { MdbAccordionComponent, MdbAccordionItemBodyDirective, MdbAccordionItemComponent, MdbAccordionItemHeaderDirective, MdbAccordionModule };
