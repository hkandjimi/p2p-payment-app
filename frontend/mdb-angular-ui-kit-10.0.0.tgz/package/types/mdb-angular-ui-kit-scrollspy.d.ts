import * as i0 from '@angular/core';
import { OnInit, ChangeDetectorRef, QueryList, AfterContentInit, OnDestroy, EventEmitter, ElementRef, Renderer2, AfterViewInit, NgZone } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';

declare class MdbScrollspyLinkDirective implements OnInit {
    private cdRef;
    private document;
    get scrollIntoView(): boolean;
    set scrollIntoView(value: boolean);
    private _scrollIntoView;
    get section(): HTMLElement;
    set section(value: HTMLElement);
    private _section;
    private _id;
    constructor(cdRef: ChangeDetectorRef, document: any);
    get id(): string;
    set id(newId: string);
    scrollspyLink: boolean;
    active: boolean;
    onClick(): void;
    detectChanges(): void;
    assignSectionToId(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbScrollspyLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbScrollspyLinkDirective, "[mdbScrollspyLink]", never, { "scrollIntoView": { "alias": "scrollIntoView"; "required": false; }; "id": { "alias": "mdbScrollspyLink"; "required": false; }; }, {}, never, never, false, never>;
}

interface MdbScrollspy {
    id: string;
    links: QueryList<MdbScrollspyLinkDirective>;
}
declare class MdbScrollspyService {
    scrollSpys: MdbScrollspy[];
    private activeSubject;
    active$: Observable<any>;
    addScrollspy(scrollSpy: MdbScrollspy): void;
    removeScrollspy(scrollSpyId: string): void;
    updateActiveState(scrollSpyId: string, activeLinkId: string): void;
    removeActiveState(scrollSpyId: string, activeLinkId: string): void;
    setActiveLink(activeLink: MdbScrollspyLinkDirective | any): void;
    removeActiveLinks(scrollSpyId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbScrollspyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MdbScrollspyService>;
}

declare class MdbScrollspyDirective implements OnInit, AfterContentInit, OnDestroy {
    private scrollSpyService;
    private _elementRef;
    private _renderer;
    links: QueryList<MdbScrollspyLinkDirective>;
    readonly _destroy$: Subject<void>;
    get id(): string;
    set id(newId: string);
    private _id;
    get collapsible(): boolean;
    set collapsible(value: boolean);
    private _collapsible;
    private _isBrowser;
    activeLinkChange: EventEmitter<any>;
    activeSub: Subscription;
    constructor(scrollSpyService: MdbScrollspyService, _elementRef: ElementRef, _renderer: Renderer2, platformId: Object);
    get host(): HTMLElement;
    collapsibleElementHeight: number;
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private styleCollapsibleElement;
    private getAllSiblings;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbScrollspyDirective, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbScrollspyDirective, "[mdbScrollspy]", never, { "id": { "alias": "mdbScrollspy"; "required": false; }; "collapsible": { "alias": "collapsible"; "required": false; }; }, { "activeLinkChange": "activeLinkChange"; }, ["links"], ["*"], false, never>;
}

declare class MdbScrollspyElementDirective implements OnInit, AfterViewInit, OnDestroy {
    private _elementRef;
    private renderer;
    private ngZone;
    private scrollSpyService;
    private _document;
    private id;
    private _unlisten;
    private _lastInView;
    get host(): HTMLElement;
    container: HTMLElement;
    get scrollSpyId(): string;
    set scrollSpyId(newId: string);
    private _scrollSpyId;
    offset: number;
    constructor(_elementRef: ElementRef, renderer: Renderer2, ngZone: NgZone, scrollSpyService: MdbScrollspyService, _document: any);
    isElementInViewport(): boolean;
    updateActiveState(scrollSpyId: string, id: string): void;
    onScroll(): void;
    listenToScroll(): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private _getClosestEl;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbScrollspyElementDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbScrollspyElementDirective, "[mdbScrollspyElement]", never, { "container": { "alias": "container"; "required": false; }; "scrollSpyId": { "alias": "mdbScrollspyElement"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MdbScrollspyWindowDirective implements OnInit, AfterViewInit, OnDestroy {
    private document;
    private el;
    private renderer;
    private ngZone;
    private scrollSpyService;
    private id;
    private _unlisten;
    private _lastInView;
    get scrollSpyId(): string;
    set scrollSpyId(newId: string);
    private _scrollSpyId;
    offset: number;
    constructor(document: any, el: ElementRef, renderer: Renderer2, ngZone: NgZone, scrollSpyService: MdbScrollspyService);
    isElementInViewport(): boolean;
    updateActiveState(scrollSpyId: string, id: string): void;
    onScroll(): void;
    listenToScroll(): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbScrollspyWindowDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbScrollspyWindowDirective, "[mdbScrollspyWindow]", never, { "scrollSpyId": { "alias": "mdbScrollspyWindow"; "required": false; }; "offset": { "alias": "offset"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MdbScrollspyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbScrollspyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbScrollspyModule, [typeof MdbScrollspyDirective, typeof MdbScrollspyLinkDirective, typeof MdbScrollspyElementDirective, typeof MdbScrollspyWindowDirective], never, [typeof MdbScrollspyDirective, typeof MdbScrollspyLinkDirective, typeof MdbScrollspyElementDirective, typeof MdbScrollspyWindowDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbScrollspyModule>;
}

export { MdbScrollspyDirective, MdbScrollspyElementDirective, MdbScrollspyLinkDirective, MdbScrollspyModule, MdbScrollspyService, MdbScrollspyWindowDirective };
