import * as i0 from '@angular/core';
import { ViewContainerRef, OnInit, AfterViewInit, OnDestroy, ElementRef, Renderer2, NgZone, ComponentRef, EmbeddedViewRef, Injector, TemplateRef } from '@angular/core';
import * as i3 from '@angular/cdk/overlay';
import { OverlayRef, Overlay } from '@angular/cdk/overlay';
import { Subject, Observable } from 'rxjs';
import * as i4 from '@angular/cdk/portal';
import { CdkPortalOutlet, ComponentPortal, TemplatePortal, ComponentType } from '@angular/cdk/portal';
import { ConfigurableFocusTrapFactory } from '@angular/cdk/a11y';
import * as i2 from '@angular/common';

declare class MdbModalConfig<D = any> {
    animation?: boolean;
    backdrop?: boolean;
    ignoreBackdropClick?: boolean;
    keyboard?: boolean;
    modalClass?: string;
    containerClass?: string;
    viewContainerRef?: ViewContainerRef;
    data?: D | null;
    nonInvasive?: boolean;
    focusElementSelector?: string;
}

declare class MdbModalContainerComponent implements OnInit, AfterViewInit, OnDestroy {
    private _document;
    _elementRef: ElementRef;
    private _renderer;
    private _focusTrapFactory;
    private _ngZone;
    _portalOutlet: CdkPortalOutlet;
    modalDialog: ElementRef;
    modalContent: ElementRef;
    readonly _destroy$: Subject<void>;
    readonly backdropClick$: Subject<MouseEvent>;
    _config: MdbModalConfig;
    BACKDROP_TRANSITION: number;
    MODAL_TRANSITION: number;
    NON_INVASIVE_TRANSITION: number;
    private _previouslyFocusedElement;
    private _focusTrap;
    modal: boolean;
    get hasAnimation(): boolean;
    onWindowResize(): void;
    get host(): HTMLElement;
    private _isScrollable;
    private _isBottomRight;
    private _isBottomLeft;
    private _isTopRight;
    private _isTopLeft;
    private _isSideTopModal;
    private _isSideBottomModal;
    private _isSideModal;
    private _isModalBottom;
    private _modalContentRect;
    private _modalContentComputedStyles;
    private _modalDialogComputedStyles;
    private _topOffset;
    private _leftOffset;
    private _rightOffset;
    private _bottomOffset;
    constructor(_document: any, _elementRef: ElementRef, _renderer: Renderer2, _focusTrapFactory: ConfigurableFocusTrapFactory, _ngZone: NgZone);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private _updateContainerClass;
    private _onNonInvasiveModalShown;
    private _setNonInvasiveStyles;
    _onNonInvasiveModalHidden(): void;
    private _resetNonInvasiveStyles;
    private _removeNonInvasiveClass;
    private _handleWindowResize;
    _close(): void;
    _restoreScrollbar(): void;
    attachComponentPortal<T>(portal: ComponentPortal<T>): ComponentRef<T>;
    attachTemplatePortal<C>(portal: TemplatePortal<C>): EmbeddedViewRef<C>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbModalContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbModalContainerComponent, "mdb-modal-container", never, {}, {}, never, never, false, never>;
}

declare class MdbModalRef<T> {
    protected _overlayRef: OverlayRef;
    private _container;
    constructor(_overlayRef: OverlayRef, _container: MdbModalContainerComponent);
    component: T;
    private readonly onClose$;
    readonly onClose: Observable<any>;
    close(message?: any): void;
}

declare class MdbModalService {
    private _document;
    private _overlay;
    private _injector;
    constructor(_document: any, _overlay: Overlay, _injector: Injector);
    open<T, D = any>(componentOrTemplateRef: ComponentType<T> | TemplateRef<T>, config?: MdbModalConfig<D>): MdbModalRef<T>;
    private _createOverlay;
    private _getOverlayConfig;
    private _createContainer;
    private _createContent;
    private _createInjector;
    private _registerListeners;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbModalService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MdbModalService>;
}

declare class MdbModalModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbModalModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbModalModule, [typeof MdbModalContainerComponent], [typeof i2.CommonModule, typeof i3.OverlayModule, typeof i4.PortalModule], [typeof MdbModalContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbModalModule>;
}

export { MdbModalConfig, MdbModalContainerComponent, MdbModalModule, MdbModalRef, MdbModalService };
