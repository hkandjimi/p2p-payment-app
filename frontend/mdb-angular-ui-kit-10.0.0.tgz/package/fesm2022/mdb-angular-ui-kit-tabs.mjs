import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i2 from '@angular/cdk/portal';
import { TemplatePortal, CdkPortalOutlet, PortalModule } from '@angular/cdk/portal';
import * as i0 from '@angular/core';
import { InjectionToken, Directive, TemplateRef, Input, ViewChild, ContentChild, Component, DOCUMENT, Inject, inject, ChangeDetectorRef, EventEmitter, Output, HostBinding, ContentChildren, NgModule } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

const MDB_TAB_CONTENT = new InjectionToken('MdbTabContentDirective');
class MdbTabContentDirective {
    template;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabContentDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: MdbTabContentDirective, isStandalone: false, selector: "[mdbTabContent]", providers: [{ provide: MDB_TAB_CONTENT, useExisting: MdbTabContentDirective }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabContentDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbTabContent]',
                    providers: [{ provide: MDB_TAB_CONTENT, useExisting: MdbTabContentDirective }],
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });

const MDB_TAB_TITLE = new InjectionToken('MdbTabTitleDirective');
class MdbTabTitleDirective {
    template;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabTitleDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: MdbTabTitleDirective, isStandalone: false, selector: "[mdbTabTitle]", providers: [{ provide: MDB_TAB_TITLE, useExisting: MdbTabTitleDirective }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabTitleDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbTabTitle]',
                    providers: [{ provide: MDB_TAB_TITLE, useExisting: MdbTabTitleDirective }],
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });

const SHOW_TRANSITION_DELAY = 150; // Time of transition taken from styles
const TRANSITION_PADDING = 5; // Value from standard added via executeAfterTransition function
class MdbTabComponent {
    _vcr;
    _cdRef;
    _lazyContent;
    _titleContent;
    _content;
    activeStateChange$ = new Subject();
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    _disabled = false;
    get fade() {
        return this._fade;
    }
    set fade(value) {
        this._fade = coerceBooleanProperty(value);
    }
    _fade = true;
    title;
    get content() {
        return this._contentPortal;
    }
    get titleContent() {
        return this._titlePortal;
    }
    get shouldAttach() {
        return this._lazyContent === undefined;
    }
    _contentPortal = null;
    _titlePortal = null;
    get active() {
        return this._active;
    }
    set active(value) {
        this._active = coerceBooleanProperty(value);
        this.activeStateChange$.next(value);
    }
    _active = false;
    get show() {
        return this._show;
    }
    set show(value) {
        // We use setTimeout to apply delay for setting show class to reproduce standard library where
        // show class is applied after a delay to newly activated item via usage of _queueCallback and
        // executeAfterTransition functions which introduce delay equal to transition time taken from
        // element styles
        setTimeout(() => {
            this._show = coerceBooleanProperty(value);
            this._cdRef.markForCheck();
        }, SHOW_TRANSITION_DELAY + TRANSITION_PADDING);
    }
    _show = true;
    constructor(_vcr, _cdRef) {
        this._vcr = _vcr;
        this._cdRef = _cdRef;
    }
    ngOnInit() {
        this._createContentPortal();
        if (this._titleContent) {
            this._createTitlePortal();
        }
    }
    _createContentPortal() {
        const content = this._lazyContent || this._content;
        this._contentPortal = new TemplatePortal(content, this._vcr);
    }
    _createTitlePortal() {
        this._titlePortal = new TemplatePortal(this._titleContent, this._vcr);
    }
    static ngAcceptInputType_disabled;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabComponent, deps: [{ token: i0.ViewContainerRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.1.2", type: MdbTabComponent, isStandalone: false, selector: "mdb-tab", inputs: { disabled: "disabled", fade: "fade", title: "title" }, queries: [{ propertyName: "_lazyContent", first: true, predicate: MDB_TAB_CONTENT, descendants: true, read: TemplateRef, static: true }, { propertyName: "_titleContent", first: true, predicate: MDB_TAB_TITLE, descendants: true, read: TemplateRef, static: true }], viewQueries: [{ propertyName: "_content", first: true, predicate: TemplateRef, descendants: true, static: true }], ngImport: i0, template: "<ng-template><ng-content></ng-content></ng-template>\n" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-tab', standalone: false, template: "<ng-template><ng-content></ng-content></ng-template>\n" }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: i0.ChangeDetectorRef }], propDecorators: { _lazyContent: [{
                type: ContentChild,
                args: [MDB_TAB_CONTENT, { read: TemplateRef, static: true }]
            }], _titleContent: [{
                type: ContentChild,
                args: [MDB_TAB_TITLE, { read: TemplateRef, static: true }]
            }], _content: [{
                type: ViewChild,
                args: [TemplateRef, { static: true }]
            }], disabled: [{
                type: Input
            }], fade: [{
                type: Input
            }], title: [{
                type: Input
            }] } });

// eslint-disable-next-line @angular-eslint/directive-class-suffix
class MdbTabPortalOutlet extends CdkPortalOutlet {
    _destroy$ = new Subject();
    tab;
    constructor(_vcr, _document) {
        super(_vcr, _document);
    }
    ngOnInit() {
        super.ngOnInit();
        if ((this.tab.shouldAttach || this.tab.active) && !this.hasAttached()) {
            this.attach(this.tab.content);
        }
        else {
            this.tab.activeStateChange$.pipe(takeUntil(this._destroy$)).subscribe((isActive) => {
                if (isActive && !this.hasAttached()) {
                    this.attach(this.tab.content);
                }
            });
        }
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
        super.ngOnDestroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabPortalOutlet, deps: [{ token: i0.ViewContainerRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.1.2", type: MdbTabPortalOutlet, isStandalone: false, selector: "[mdbTabPortalOutlet]", inputs: { tab: "tab" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabPortalOutlet, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbTabPortalOutlet]',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { tab: [{
                type: Input
            }] } });

class MdbTabChange {
    index;
    tab;
}
class MdbTabsComponent {
    tabs;
    _destroy$ = new Subject();
    get fill() {
        return this._fill;
    }
    set fill(value) {
        this._fill = coerceBooleanProperty(value);
    }
    _fill = false;
    get justified() {
        return this._justified;
    }
    set justified(value) {
        this._justified = coerceBooleanProperty(value);
    }
    _justified = false;
    get pills() {
        return this._pills;
    }
    set pills(value) {
        this._pills = coerceBooleanProperty(value);
    }
    _pills = false;
    get vertical() {
        return this._vertical;
    }
    set vertical(value) {
        this._vertical = coerceBooleanProperty(value);
    }
    _vertical = false;
    navColumnClass = 'col-3';
    contentColumnClass = 'col-9';
    _cdRef = inject(ChangeDetectorRef);
    get navColClass() {
        return this.vertical ? this.navColumnClass : '';
    }
    get contentColClass() {
        return this.vertical ? this.contentColumnClass : '';
    }
    _selectedIndex;
    activeTabChange = new EventEmitter();
    ngAfterContentInit() {
        const firstActiveTabIndex = this.tabs.toArray().findIndex((tab) => !tab.disabled);
        this.setActiveTab(firstActiveTabIndex);
        this.tabs.changes.pipe(takeUntil(this._destroy$)).subscribe(() => {
            const hasActiveTab = this.tabs.find((tab) => tab.active);
            if (!hasActiveTab) {
                const closestTabIndex = this._getClosestTabIndex(this._selectedIndex);
                if (closestTabIndex !== -1) {
                    this.setActiveTab(closestTabIndex);
                }
            }
        });
    }
    setActiveTab(index) {
        const activeTab = this.tabs.toArray()[index];
        if (!activeTab || (activeTab && activeTab.disabled)) {
            return;
        }
        this.tabs.forEach((tab) => (tab.active = tab === activeTab));
        this.tabs.forEach((tab) => (tab.show = tab === activeTab));
        this._selectedIndex = index;
        const tabChangeEvent = this._getTabChangeEvent(index, activeTab);
        this.activeTabChange.emit(tabChangeEvent);
        this._cdRef.markForCheck();
    }
    _getTabChangeEvent(index, tab) {
        const event = new MdbTabChange();
        event.index = index;
        event.tab = tab;
        return event;
    }
    _getClosestTabIndex(index) {
        const tabs = this.tabs.toArray();
        const tabsLength = tabs.length;
        if (!tabsLength) {
            return -1;
        }
        for (let i = 1; i <= tabsLength; i += 1) {
            const prevIndex = index - i;
            const nextIndex = index + i;
            if (tabs[prevIndex] && !tabs[prevIndex].disabled) {
                return prevIndex;
            }
            if (tabs[nextIndex] && !tabs[nextIndex].disabled) {
                return nextIndex;
            }
        }
        return -1;
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
    }
    static ngAcceptInputType_fill;
    static ngAcceptInputType_justified;
    static ngAcceptInputType_pills;
    static ngAcceptInputType_vertical;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.1.2", type: MdbTabsComponent, isStandalone: false, selector: "mdb-tabs", inputs: { fill: "fill", justified: "justified", pills: "pills", vertical: "vertical", navColumnClass: "navColumnClass", contentColumnClass: "contentColumnClass" }, outputs: { activeTabChange: "activeTabChange" }, host: { properties: { "class.row": "this.vertical" } }, queries: [{ propertyName: "tabs", predicate: MdbTabComponent }], ngImport: i0, template: "<ul\n  class=\"nav mb-3 flex-column {{ navColClass }}\"\n  [ngClass]=\"{\n    'nav-pills': pills,\n    'nav-tabs': !pills,\n    'nav-fill': fill,\n    'nav-justified': justified,\n    'flex-column': vertical,\n    'text-center': vertical\n  }\"\n  role=\"tablist\"\n>\n  @for (tab of tabs; track tab; let i = $index) {\n  <li (click)=\"setActiveTab(i)\" class=\"nav-item\" role=\"presentation\">\n    <a\n      href=\"javascript:void(0)\"\n      class=\"nav-link\"\n      [class.active]=\"tab.active\"\n      [class.disabled]=\"tab.disabled\"\n      role=\"tab\"\n    >\n      @if (tab.titleContent) {\n      <ng-template [cdkPortalOutlet]=\"tab.titleContent\"></ng-template>\n      } @if (!tab.titleContent) {\n      {{ tab.title }}\n      }\n    </a>\n  </li>\n  }\n</ul>\n\n<div class=\"tab-content {{ contentColClass }}\">\n  <!-- <ng-content select=\"mdb-tab\"></ng-content> -->\n  @for (tab of tabs; track tab) {\n  <div\n    class=\"tab-pane\"\n    [ngClass]=\"{\n      fade: tab.fade,\n      active: tab.active,\n      show: tab.show\n    }\"\n  >\n    <ng-template mdbTabPortalOutlet [tab]=\"tab\"></ng-template>\n  </div>\n  }\n</div>\n", dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.CdkPortalOutlet, selector: "[cdkPortalOutlet]", inputs: ["cdkPortalOutlet"], outputs: ["attached"], exportAs: ["cdkPortalOutlet"] }, { kind: "directive", type: MdbTabPortalOutlet, selector: "[mdbTabPortalOutlet]", inputs: ["tab"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-tabs', standalone: false, template: "<ul\n  class=\"nav mb-3 flex-column {{ navColClass }}\"\n  [ngClass]=\"{\n    'nav-pills': pills,\n    'nav-tabs': !pills,\n    'nav-fill': fill,\n    'nav-justified': justified,\n    'flex-column': vertical,\n    'text-center': vertical\n  }\"\n  role=\"tablist\"\n>\n  @for (tab of tabs; track tab; let i = $index) {\n  <li (click)=\"setActiveTab(i)\" class=\"nav-item\" role=\"presentation\">\n    <a\n      href=\"javascript:void(0)\"\n      class=\"nav-link\"\n      [class.active]=\"tab.active\"\n      [class.disabled]=\"tab.disabled\"\n      role=\"tab\"\n    >\n      @if (tab.titleContent) {\n      <ng-template [cdkPortalOutlet]=\"tab.titleContent\"></ng-template>\n      } @if (!tab.titleContent) {\n      {{ tab.title }}\n      }\n    </a>\n  </li>\n  }\n</ul>\n\n<div class=\"tab-content {{ contentColClass }}\">\n  <!-- <ng-content select=\"mdb-tab\"></ng-content> -->\n  @for (tab of tabs; track tab) {\n  <div\n    class=\"tab-pane\"\n    [ngClass]=\"{\n      fade: tab.fade,\n      active: tab.active,\n      show: tab.show\n    }\"\n  >\n    <ng-template mdbTabPortalOutlet [tab]=\"tab\"></ng-template>\n  </div>\n  }\n</div>\n" }]
        }], propDecorators: { tabs: [{
                type: ContentChildren,
                args: [MdbTabComponent]
            }], fill: [{
                type: Input
            }], justified: [{
                type: Input
            }], pills: [{
                type: Input
            }], vertical: [{
                type: HostBinding,
                args: ['class.row']
            }, {
                type: Input
            }], navColumnClass: [{
                type: Input
            }], contentColumnClass: [{
                type: Input
            }], activeTabChange: [{
                type: Output
            }] } });

class MdbTabsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "21.1.2", ngImport: i0, type: MdbTabsModule, declarations: [MdbTabComponent,
            MdbTabContentDirective,
            MdbTabTitleDirective,
            MdbTabPortalOutlet,
            MdbTabsComponent], imports: [CommonModule, PortalModule], exports: [MdbTabComponent,
            MdbTabContentDirective,
            MdbTabTitleDirective,
            MdbTabPortalOutlet,
            MdbTabsComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabsModule, imports: [CommonModule, PortalModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.1.2", ngImport: i0, type: MdbTabsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        MdbTabComponent,
                        MdbTabContentDirective,
                        MdbTabTitleDirective,
                        MdbTabPortalOutlet,
                        MdbTabsComponent,
                    ],
                    imports: [CommonModule, PortalModule],
                    exports: [
                        MdbTabComponent,
                        MdbTabContentDirective,
                        MdbTabTitleDirective,
                        MdbTabPortalOutlet,
                        MdbTabsComponent,
                    ],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MdbTabChange, MdbTabComponent, MdbTabContentDirective, MdbTabPortalOutlet, MdbTabTitleDirective, MdbTabsComponent, MdbTabsModule };
//# sourceMappingURL=mdb-angular-ui-kit-tabs.mjs.map
